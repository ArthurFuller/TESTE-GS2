using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

[ExecuteAlways]
public sealed class DayTimeline : MonoBehaviour
{
    [SerializeField] private DayCycle days;
    [SerializeField] private ActionResolver actions;
    [SerializeField] private DayEventController dayEvents;
    [SerializeField] private ActiveMissionsPanel activeMissionsPanel;
    [SerializeField] private SeedMerchant merchant;
    [SerializeField] private ActivityCardAvailability hand;
    [SerializeField] private RectTransform topBar;
    [SerializeField] private RectTransform missionsButton;
    [SerializeField] private Font font;
    [SerializeField, Min(1)] private int totalDays = 12;
    [Header("Padrões para elementos novos")]
    [SerializeField, Min(170f)] private float panelWidth = 380f;
    [SerializeField, Min(44f)] private float daysHeight = 96f;
    [SerializeField, Min(120f)] private float cardsHeight = 160f;
    [SerializeField, Min(30f)] private float topBarHeight = 78f;
    [SerializeField, InspectorName("Deslocamento do painel")]
    private Vector2 panelOffset;
    [SerializeField, Min(24f)] private float dayButtonWidth = 34f;
    [SerializeField, Min(20f)] private float dayButtonHeight = 22f;
    [SerializeField, Min(1f)] private float dayLineHeight = 3f;
    [Header("Cartas geradas no histórico")]
    [SerializeField, Min(45f)] private float cardWidth = 60f;
    [SerializeField, Min(65f)] private float cardHeight = 83f;
    [SerializeField, Min(0f)] private float cardGap = 10f;
    [SerializeField, Min(1f)] private float cardLineHeight = 3f;
    [SerializeField, Min(0f)] private float cardOverlap = 34f;
    [SerializeField, Min(1f)] private float pegSize = 18f;
    [SerializeField, Range(0f, 15f)] private float hangingAngle = 7f;
    [SerializeField, Min(1f)] private float cardHoverScale = 1.2f;
    [SerializeField] private Sprite clothespinArt;
    [SerializeField, Min(0f)] private float cardStartX = 18f;
    [SerializeField, Min(0f)] private float cardTopInset = 8f;
    [SerializeField] private float cardLineOffsetY;
    [Header("Animação")]
    [SerializeField, Min(0.05f)] private float slideDuration = 0.36f;
    [SerializeField, Min(0f)] private float waveDelay = 0.055f;
    [Header("Inspeção da carta")]
    [SerializeField, Range(0f, 35f)] private float inspectionTilt = 22f;
    [SerializeField, Min(0f)] private float inspectionShift = 14f;
    [SerializeField, Min(0.1f)] private float inspectionFollowSpeed = 12f;

    private sealed class PlayedCard
    {
        public string Name;
        public string Description;
        public Sprite Art;
    }

    private readonly Dictionary<int, List<PlayedCard>> history = new();
    private RectTransform panelClip;
    private RectTransform panel;
    private RectTransform trigger;
    private RectTransform dayRow;
    private RectTransform dayContent;
    private ScrollRect dayScroll;
    private RectTransform cardScroll;
    private RectTransform cardContent;
    private ScrollRect scroll;
    private Button triggerButton;
    private Button backButton;
    private Text title;
    private CanvasGroup panelGroup;
    private readonly List<RectTransform> dayNodes = new();
    private readonly List<RectTransform> dayLines = new();
    private readonly List<RectTransform> cardNodes = new();
    private readonly List<RectTransform> cardLines = new();
    private readonly Dictionary<RectTransform, float> dayHomeY = new();
    private Vector2 daysPanelSize;
    private Vector2 panelHomePosition;
    private bool open;
    private int viewedDay;
    private RectTransform inspectionCard;
    private RectTransform inspectionShade;
    private RectTransform inspectionDescription;
    private CanvasGroup inspectionSource;
    private Sequence inspectionTween;
    private bool inspectionFromTimeline;
    private TopBarAutoHide topBarMotion;
    private Vector2 hudOffset;

    public RectTransform PanelClip => panelClip;
    public RectTransform TimelinePanel => panel;
    public Vector2 PanelHomePosition => panelHomePosition;
    public bool IsOpen => open;
    public Vector2 PanelClipPosition => new Vector2(-2f,
        -Mathf.Max(topBarHeight, topBar != null ? topBar.rect.height : 0f)) +
        panelOffset + hudOffset;

    public void FollowHud(Vector2 offset)
    {
        hudOffset = offset;
        if (panelClip != null) panelClip.anchoredPosition = PanelClipPosition;
    }

    private void Awake()
    {
        EnsureUI();
        if (Application.isPlaying) CloseImmediately();
    }

    private void OnEnable()
    {
#if UNITY_EDITOR
        if (!Application.isPlaying)
        {
            UnityEditor.EditorApplication.delayCall -= RefreshEditor;
            UnityEditor.EditorApplication.delayCall += RefreshEditor;
            return;
        }
#endif
        if (dayEvents == null) dayEvents = FindFirstObjectByType<DayEventController>();
        if (actions != null) actions.CardPlayed += Record;
        if (days != null) days.DayChanged += RefreshDays;
        EnsureUI();
        RefreshDays();
    }

    private void OnDisable()
    {
        CloseInspection(true);
#if UNITY_EDITOR
        UnityEditor.EditorApplication.delayCall -= RefreshEditor;
        UnityEditor.EditorApplication.delayCall -= RefreshInspector;
#endif
        if (actions != null) actions.CardPlayed -= Record;
        if (days != null) days.DayChanged -= RefreshDays;
        if (panel != null) panel.DOKill();
        DOTween.Kill(this);
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        UnityEditor.EditorApplication.delayCall -= RefreshInspector;
        UnityEditor.EditorApplication.delayCall += RefreshInspector;
    }

    private void RefreshInspector()
    {
        if (this == null) return;
        if (!Application.isPlaying)
        {
            RefreshEditor();
            return;
        }
        if (panelClip != null) panelClip.anchoredPosition = PanelClipPosition;
        if (inspectionCard != null)
        {
            TimelineCardInspection inspection =
                inspectionCard.GetComponent<TimelineCardInspection>();
            if (inspection != null)
                inspection.Configure(inspectionTilt, inspectionShift,
                    inspectionFollowSpeed);
            return;
        }
        if (open && viewedDay > 0 && cardScroll != null &&
            cardScroll.gameObject.activeInHierarchy)
            RenderCards(viewedDay, false);
    }

    private void RefreshEditor()
    {
        if (this == null || Application.isPlaying) return;
        EnsureUI();
        if (panelClip != null) panelClip.anchoredPosition = PanelClipPosition;
        RefreshDays();
        if (panelGroup != null)
        {
            if (panelGroup.alpha <= 0f) panelGroup.alpha = 1f;
            panelGroup.interactable = panelGroup.blocksRaycasts = false;
        }
    }
#endif

    private void Record(int day, ActivityCardDrag card)
    {
        if (card == null) return;
        if (!history.TryGetValue(day, out List<PlayedCard> cards))
        {
            cards = new List<PlayedCard>();
            history.Add(day, cards);
        }
        Image image = card.GetComponent<Image>();
        cards.Add(new PlayedCard { Name = card.DisplayName,
            Description = card.Description,
            Art = image != null ? image.sprite : null });
        if (open && viewedDay == day) RenderCards(day, false);
    }

    private void Update()
    {
        if (inspectionCard != null && Keyboard.current != null &&
            Keyboard.current.escapeKey.wasPressedThisFrame)
            CloseInspection(false);
        if (Application.isPlaying && open && days != null && !days.CanAcceptActions)
            Close();
    }

    private void EnsureUI()
    {
        if (topBar == null || missionsButton == null) return;
        if (topBarMotion == null) topBarMotion = topBar.GetComponent<TopBarAutoHide>();
        if (font == null)
        {
            Text reference = GetComponentInChildren<Text>(true);
            if (reference != null) font = reference.font;
        }
        if (font == null) return;
        Canvas canvas = GetComponent<Canvas>();
        if (canvas == null) return;
        bool created = false;

        trigger = topBar.Find("Botão da linha do tempo") as RectTransform;
        if (trigger == null)
        {
            created = true;
            trigger = Box("Botão da linha do tempo", topBar,
                new Color(0.16f, 0.16f, 0.13f), true);
            Label("DIAS", trigger, 14, Color.white);
        }
        triggerButton = trigger.GetComponent<Button>();
        triggerButton.onClick.RemoveAllListeners();
        triggerButton.onClick.AddListener(Toggle);

        panelClip = transform.Find("Recorte da linha do tempo") as RectTransform;
        if (panelClip == null)
        {
            created = true;
            panelClip = Empty("Recorte da linha do tempo", transform);
        }
        if (panelClip.GetComponent<RectMask2D>() == null)
            panelClip.gameObject.AddComponent<RectMask2D>();
        if (panelClip.parent == topBar.parent &&
            panelClip.GetSiblingIndex() > topBar.GetSiblingIndex())
            panelClip.SetSiblingIndex(topBar.GetSiblingIndex());

        panel = panelClip.Find("Linha do tempo") as RectTransform;
        if (panel == null)
        {
            panel = transform.Find("Linha do tempo") as RectTransform;
            if (panel != null) panel.SetParent(panelClip, false);
        }
        if (panel == null)
        {
            created = true;
            panel = Box("Linha do tempo", panelClip,
                new Color(0.88f, 0.82f, 0.65f, 0.98f), false);
        }
        panelGroup = panel.GetComponent<CanvasGroup>();
        if (panelGroup == null) panelGroup = panel.gameObject.AddComponent<CanvasGroup>();
        if (panel.GetComponent<RectMask2D>() == null)
            panel.gameObject.AddComponent<RectMask2D>();
        dayRow = panel.Find("Dias") as RectTransform;
        if (dayRow == null) { created = true; dayRow = Empty("Dias", panel); }
        Image dayImage = dayRow.GetComponent<Image>();
        if (dayImage == null)
        {
            dayImage = dayRow.gameObject.AddComponent<Image>();
            dayImage.color = new Color(1f, 1f, 1f, 0.01f);
        }
        if (dayRow.GetComponent<Mask>() == null)
            dayRow.gameObject.AddComponent<Mask>().showMaskGraphic = false;
        dayScroll = dayRow.GetComponent<ScrollRect>();
        if (dayScroll == null)
        {
            dayScroll = dayRow.gameObject.AddComponent<ScrollRect>();
            dayScroll.horizontal = true;
            dayScroll.vertical = false;
            dayScroll.movementType = ScrollRect.MovementType.Clamped;
        }
        dayContent = dayRow.Find("Conteúdo dos dias") as RectTransform;
        if (dayContent == null)
        {
            created = true;
            dayContent = Empty("Conteúdo dos dias", dayRow);
            for (int i = dayRow.childCount - 1; i >= 0; i--)
            {
                Transform old = dayRow.GetChild(i);
                if (old != dayContent) old.SetParent(dayContent, false);
            }
        }
        if (dayScroll.viewport == null) dayScroll.viewport = dayRow;
        if (dayScroll.content == null) dayScroll.content = dayContent;
        dayScroll.scrollSensitivity = 15f;
        cardScroll = panel.Find("Rolagem de cartas") as RectTransform;
        if (cardScroll == null)
        {
            created = true;
            cardScroll = Empty("Rolagem de cartas", panel);
        }
        scroll = cardScroll.GetComponent<ScrollRect>();
        if (scroll == null)
        {
            scroll = cardScroll.gameObject.AddComponent<ScrollRect>();
            scroll.horizontal = true;
            scroll.vertical = false;
            scroll.movementType = ScrollRect.MovementType.Clamped;
            scroll.inertia = true;
        }
        RectTransform viewport = cardScroll.Find("Janela") as RectTransform;
        if (viewport == null)
        {
            created = true;
            viewport = Box("Janela", cardScroll,
                new Color(1f, 1f, 1f, 0.01f), false);
            Mask mask = viewport.gameObject.AddComponent<Mask>();
            mask.showMaskGraphic = false;
        }
        cardContent = viewport.Find("Cartas em ordem") as RectTransform;
        if (cardContent == null)
        {
            created = true;
            cardContent = Empty("Cartas em ordem", viewport);
        }
        if (scroll.viewport == null) scroll.viewport = viewport;
        if (scroll.content == null) scroll.content = cardContent;
        RectTransform titleRect = panel.Find("Título do dia") as RectTransform;
        if (titleRect == null) titleRect = Label("Título do dia", panel, 14,
            new Color(0.19f, 0.17f, 0.13f));
        title = titleRect.GetComponent<Text>();
        RectTransform back = panel.Find("Voltar aos dias") as RectTransform;
        if (back == null)
        {
            created = true;
            back = Box("Voltar aos dias", panel,
                new Color(0.22f, 0.2f, 0.16f), true);
            Label("< DIAS", back, 11, Color.white);
        }
        backButton = back.GetComponent<Button>();
        backButton.onClick.RemoveAllListeners();
        backButton.onClick.AddListener(BackToDays);
        if (created) Layout();
        if (!Application.isPlaying || daysPanelSize == Vector2.zero)
        {
            daysPanelSize = panel.sizeDelta;
            panelHomePosition = panel.anchoredPosition;
        }
    }

    private void Layout()
    {
        if (panel == null || trigger == null) return;
        trigger.anchorMin = trigger.anchorMax = new Vector2(0f, 1f);
        trigger.pivot = new Vector2(0f, 1f);
        trigger.sizeDelta = new Vector2(45f, missionsButton.rect.height);
        trigger.anchoredPosition = missionsButton.anchoredPosition +
            new Vector2(-trigger.rect.width - 8f, 0f);
        panelClip.anchorMin = panelClip.anchorMax = new Vector2(1f, 1f);
        panelClip.pivot = new Vector2(1f, 1f);
        panelClip.sizeDelta = new Vector2(panelWidth, cardsHeight);
        panelClip.anchoredPosition = PanelClipPosition;
        panel.anchorMin = panel.anchorMax = new Vector2(1f, 1f);
        panel.pivot = new Vector2(1f, 1f);
        panel.sizeDelta = new Vector2(panelWidth, viewedDay > 0 ? cardsHeight : daysHeight);
        if (!Application.isPlaying) panel.anchoredPosition = Vector2.zero;
        Fill(dayRow, 0f, 0f);
        dayContent.anchorMin = dayContent.anchorMax = new Vector2(0f, 1f);
        dayContent.pivot = new Vector2(0f, 1f);
        cardScroll.anchorMin = new Vector2(0f, 1f);
        cardScroll.anchorMax = new Vector2(1f, 1f);
        cardScroll.pivot = new Vector2(0.5f, 1f);
        cardScroll.anchoredPosition = new Vector2(0f, -51f);
        cardScroll.sizeDelta = new Vector2(-20f, cardsHeight - 58f);
        RectTransform viewport = scroll.viewport;
        Fill(viewport, 0f, 0f);
        cardContent.anchorMin = cardContent.anchorMax = new Vector2(0f, 1f);
        cardContent.pivot = new Vector2(0f, 1f);
        title.rectTransform.anchorMin = title.rectTransform.anchorMax = new Vector2(0.5f, 1f);
        title.rectTransform.pivot = new Vector2(0.5f, 1f);
        title.rectTransform.sizeDelta = new Vector2(160f, 19f);
        title.rectTransform.anchoredPosition = new Vector2(0f, -27f);
        RectTransform back = (RectTransform)backButton.transform;
        back.anchorMin = back.anchorMax = new Vector2(1f, 1f);
        back.pivot = new Vector2(1f, 1f);
        back.sizeDelta = new Vector2(68f, 22f);
        back.anchoredPosition = new Vector2(-7f, -26f);
    }

    private void RefreshDays()
    {
        if (dayRow == null) return;
        if (dayNodes.Count != totalDays || dayLines.Count != Mathf.Max(0, totalDays - 1))
        {
            dayNodes.Clear();
            dayLines.Clear();
            dayHomeY.Clear();
            float step = dayButtonWidth + 14f;
            for (int i = 0; i < totalDays - 1; i++)
            {
                RectTransform line = dayContent.Find("Ligação do dia " + (i + 1)) as RectTransform;
                if (line == null)
                {
                    line = Box("Ligação do dia " + (i + 1), dayContent,
                        new Color(0.32f, 0.28f, 0.2f), false);
                    line.anchorMin = line.anchorMax = new Vector2(0f, 1f);
                    line.pivot = new Vector2(0f, 0.5f);
                    line.sizeDelta = new Vector2(step, dayLineHeight);
                    line.anchoredPosition = new Vector2(
                        12f + dayButtonWidth * 0.5f + i * step, -60f);
                }
                dayLines.Add(line);
            }
            for (int i = 1; i <= totalDays; i++)
            {
                int day = i;
                RectTransform node = dayContent.Find("Dia " + day) as RectTransform;
                if (node == null)
                {
                    node = Box("Dia " + day, dayContent,
                        new Color(0.28f, 0.25f, 0.19f), true);
                    Label(day.ToString(), node, 12, Color.white);
                    node.anchorMin = node.anchorMax = new Vector2(0f, 1f);
                    node.pivot = new Vector2(0.5f, 0.5f);
                    node.sizeDelta = new Vector2(dayButtonWidth, dayButtonHeight);
                    node.anchoredPosition = new Vector2(
                        12f + dayButtonWidth * 0.5f + (i - 1) * step, -60f);
                }
                Button button = node.GetComponent<Button>();
                button.onClick.RemoveAllListeners();
                button.onClick.AddListener(() => ShowDay(day));
                dayNodes.Add(node);
            }
        }
        float rightEdge = 0f;
        foreach (RectTransform node in dayNodes)
            if (node != null)
                rightEdge = Mathf.Max(rightEdge,
                    node.anchoredPosition.x + node.rect.width * (1f - node.pivot.x));
        dayContent.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal,
            Mathf.Max(dayRow.rect.width, rightEdge + dayButtonWidth));
        foreach (RectTransform line in dayLines)
            if (!Application.isPlaying || !dayHomeY.ContainsKey(line))
                dayHomeY[line] = line.anchoredPosition.y;
        foreach (RectTransform node in dayNodes)
            if (!Application.isPlaying || !dayHomeY.ContainsKey(node))
                dayHomeY[node] = node.anchoredPosition.y;
        for (int i = 0; i < dayNodes.Count; i++)
        {
            RectTransform node = dayNodes[i];
            if (!Application.isPlaying) continue;
            Button button = node.GetComponent<Button>();
            button.interactable = days == null || i + 1 <= days.CurrentDay;
        }
    }

    private void PlaceDaysAbove()
    {
        foreach (RectTransform node in dayNodes)
            node.anchoredPosition = new Vector2(node.anchoredPosition.x,
                dayHomeY[node] + dayRow.rect.height);
        foreach (RectTransform line in dayLines)
            line.anchoredPosition = new Vector2(line.anchoredPosition.x,
                dayHomeY[line] + dayRow.rect.height);
    }

    private void AnimateDays(bool entering)
    {
        Ease ease = entering ? Ease.OutCubic : Ease.InCubic;
        for (int i = 0; i < dayNodes.Count; i++)
        {
            RectTransform node = dayNodes[i];
            node.DOKill();
            float destination = dayHomeY[node] + (entering ? 0f : dayRow.rect.height);
            node.DOAnchorPosY(destination, slideDuration * 0.65f)
                .SetDelay(i * waveDelay).SetEase(ease);
        }
        for (int i = 0; i < dayLines.Count; i++)
        {
            RectTransform line = dayLines[i];
            line.DOKill();
            float destination = dayHomeY[line] + (entering ? 0f : dayRow.rect.height);
            line.DOAnchorPosY(destination, slideDuration * 0.65f)
                .SetDelay((i + 0.5f) * waveDelay).SetEase(ease);
        }
    }

    public void Toggle()
    {
        if (!Application.isPlaying) return;
        if (open) Close();
        else Open();
    }

    public void ClosePanel(System.Action onClosed = null)
    {
        if (open) Close(onClosed);
        else onClosed?.Invoke();
    }

    private void Open()
    {
        if (days != null && !days.CanAcceptActions) return;
        if (activeMissionsPanel != null) activeMissionsPanel.Close();
        if (merchant != null && merchant.IsOpen) merchant.HideShop();
        EnsureUI();
        open = true;
        viewedDay = 0;
        dayRow.gameObject.SetActive(true);
        cardScroll.gameObject.SetActive(false);
        scroll.enabled = true;
        backButton.gameObject.SetActive(false);
        backButton.interactable = true;
        title.text = "LINHA DO TEMPO";
        RefreshDays();
        dayScroll.horizontalNormalizedPosition = 0f;
        PlaceDaysAbove();
        panel.DOKill();
        panel.sizeDelta = daysPanelSize;
        panel.anchoredPosition = panelHomePosition + Vector2.up * daysPanelSize.y;
        panelGroup.alpha = 1f;
        panelGroup.interactable = panelGroup.blocksRaycasts = true;
        panel.DOAnchorPosY(panelHomePosition.y, slideDuration).SetEase(Ease.OutCubic)
            .OnComplete(() => { if (open && viewedDay == 0) AnimateDays(true); });
    }

    private void Close(System.Action onClosed = null)
    {
        CloseInspection(true);
        if (viewedDay > 0 && onClosed == null)
            topBarMotion?.ReturnFromTimelineDay(null);
        open = false;
        DOTween.Kill(this);
        panel.DOKill();
        scroll.enabled = true;
        panelGroup.interactable = panelGroup.blocksRaycasts = false;
        panel.DOAnchorPosY(panelHomePosition.y + panel.rect.height, slideDuration)
            .SetEase(Ease.InCubic).OnComplete(() =>
            {
                panelGroup.alpha = 0f;
                onClosed?.Invoke();
            });
    }

    private void CloseImmediately()
    {
        CloseInspection(true);
        if (panel == null) return;
        open = false;
        viewedDay = 0;
        panelGroup.alpha = 0f;
        panelGroup.interactable = panelGroup.blocksRaycasts = false;
        panel.anchoredPosition = panelHomePosition + Vector2.up * daysPanelSize.y;
        cardScroll.gameObject.SetActive(false);
        scroll.enabled = true;
        backButton.gameObject.SetActive(false);
    }

    private void ShowDay(int day)
    {
        if (days != null && day > days.CurrentDay) return;
        viewedDay = day;
        title.text = "DIA " + day;
        foreach (RectTransform node in dayNodes)
            node.GetComponent<Button>().interactable = false;
        AnimateDays(false);
        bool daysGone = false;
        bool hudReady = topBarMotion == null;
        void ExpandWhenReady()
        {
            if (!daysGone || !hudReady || !open || viewedDay != day) return;
            dayRow.gameObject.SetActive(false);
            backButton.gameObject.SetActive(true);
            backButton.interactable = false;
            cardScroll.gameObject.SetActive(false);
            Clear(cardContent);
            panel.DOSizeDelta(new Vector2(daysPanelSize.x, panelClip.rect.height), slideDuration)
                .SetEase(Ease.OutCubic).OnComplete(() =>
                {
                    if (!open || viewedDay != day) return;
                    cardScroll.gameObject.SetActive(true);
                    RenderCards(day, true);
                    backButton.interactable = true;
                });
        }
        topBarMotion?.MoveToTimelineDay(() =>
        {
            hudReady = true;
            ExpandWhenReady();
        });
        float end = Mathf.Max(0, dayNodes.Count - 1) * waveDelay +
            slideDuration * 0.65f;
        DOVirtual.DelayedCall(end, () =>
        {
            daysGone = true;
            ExpandWhenReady();
        }).SetTarget(this);
    }

    private void BackToDays()
    {
        if (viewedDay == 0 || !cardScroll.gameObject.activeSelf) return;
        viewedDay = 0;
        backButton.interactable = false;
        scroll.enabled = false;
        AnimateCardsOut();
        bool panelReady = false;
        bool hudReady = topBarMotion == null;
        void ShowDaysWhenReady()
        {
            if (!panelReady || !hudReady || !open || viewedDay != 0) return;
            dayRow.gameObject.SetActive(true);
            RefreshDays();
            PlaceDaysAbove();
            AnimateDays(true);
            backButton.interactable = true;
        }
        topBarMotion?.ReturnFromTimelineDay(() =>
        {
            hudReady = true;
            ShowDaysWhenReady();
        });
        float end = Mathf.Max(0, cardNodes.Count - 1) * waveDelay +
            slideDuration * 0.65f;
        DOVirtual.DelayedCall(end, () =>
        {
            if (!open || viewedDay != 0) return;
            cardScroll.gameObject.SetActive(false);
            scroll.enabled = true;
            backButton.gameObject.SetActive(false);
            title.text = "LINHA DO TEMPO";
            panel.DOKill();
            panel.DOSizeDelta(daysPanelSize, slideDuration)
                .SetEase(Ease.OutCubic).OnComplete(() =>
                {
                    panelReady = true;
                    ShowDaysWhenReady();
                });
        }).SetTarget(this);
    }

    private void AnimateCardsOut()
    {
        float exitY = cardHeight + cardTopInset + 4f;
        float duration = slideDuration * 0.65f;
        for (int i = 0; i < cardNodes.Count; i++)
        {
            RectTransform card = cardNodes[i];
            if (card == null) continue;
            card.DOKill();
            card.DOAnchorPosY(exitY, duration).SetDelay(i * waveDelay)
                .SetEase(Ease.InCubic);
        }
        for (int i = 0; i < cardLines.Count; i++)
        {
            RectTransform line = cardLines[i];
            if (line == null) continue;
            line.DOKill();
            line.DOAnchorPosY(exitY, duration).SetDelay((i + 0.5f) * waveDelay)
                .SetEase(Ease.InCubic);
        }
    }

    private void RenderCards(int day, bool animate)
    {
        CloseInspection(true);
        Clear(cardContent);
        cardNodes.Clear();
        cardLines.Clear();
        var cards = new List<PlayedCard>();
        if (dayEvents != null)
            foreach (DayEventController.TimelineEvent active in dayEvents.EventsForDay(day))
                cards.Add(new PlayedCard { Name = active.Title,
                    Description = active.Description, Art = active.Art });
        if (history.TryGetValue(day, out List<PlayedCard> played)) cards.AddRange(played);
        int count = cards.Count;
        float stride = Mathf.Max(12f, cardWidth + cardGap - cardOverlap);
        float width = Mathf.Max(scroll.viewport.rect.width,
            (count - 1) * stride + cardWidth + cardStartX * 2f);
        cardContent.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, width);
        scroll.horizontalNormalizedPosition = 0f;
        if (count == 0)
        {
            RectTransform empty = Label("Nenhuma carta usada neste dia", cardContent,
                11, new Color(0.25f, 0.22f, 0.17f));
            empty.anchorMin = empty.anchorMax = new Vector2(0f, 1f);
            empty.pivot = new Vector2(0f, 1f);
            empty.anchoredPosition = new Vector2(18f, -40f);
            empty.sizeDelta = new Vector2(width - 36f, 40f);
            cardNodes.Add(empty);
            return;
        }
        float cardY = -cardTopInset - pegSize * 0.5f;
        float lineY = cardY + pegSize * 0.35f + cardLineOffsetY;
        float entryY = cardHeight + cardTopInset + 4f;
        RectTransform line = Box("Varal das cartas", cardContent,
            new Color(0.32f, 0.28f, 0.2f), false);
        line.GetComponent<Image>().raycastTarget = false;
        line.anchorMin = line.anchorMax = new Vector2(0f, 1f);
        line.pivot = new Vector2(0f, 0.5f);
        line.sizeDelta = new Vector2(width - cardStartX * 2f, cardLineHeight);
        line.anchoredPosition = new Vector2(cardStartX,
            animate ? entryY : lineY);
        cardLines.Add(line);
        if (animate)
            line.DOAnchorPosY(lineY, slideDuration).SetEase(Ease.OutCubic);
        for (int i = 0; i < count; i++)
        {
            PlayedCard data = cards[i];
            RectTransform card = Box("Carta " + (i + 1), cardContent,
                Color.white, false);
            card.anchorMin = card.anchorMax = new Vector2(0f, 1f);
            card.pivot = new Vector2(0.5f, 1f);
            card.sizeDelta = new Vector2(cardWidth, cardHeight);
            float x = cardStartX + cardWidth * 0.5f + i * stride;
            card.anchoredPosition = new Vector2(x, animate ? entryY : cardY);
            float angle = Mathf.Sin((i + 1) * 2.15f) * hangingAngle;
            card.localRotation = Quaternion.Euler(0f, 0f, angle);
            cardNodes.Add(card);
            Image art = card.GetComponent<Image>();
            art.sprite = data.Art;
            art.preserveAspect = true;
            bool placeholder = data.Art == null ||
                data.Art.name.Contains("9-SlicedBox");
            if (placeholder)
            {
                if (data.Art == null) art.color = new Color(0.92f, 0.88f, 0.76f);
                Label(data.Name, card, 9, new Color(0.55f, 0.1f, 0.1f));
            }
            if (clothespinArt != null)
            {
                RectTransform peg = Box("Pregador", card, Color.white, false);
                peg.anchorMin = peg.anchorMax = new Vector2(0.5f, 1f);
                peg.pivot = new Vector2(0.5f, 0.5f);
                // A arte tem margens transparentes largas; o retângulo compensa isso.
                peg.sizeDelta = new Vector2(pegSize * 2.7f, pegSize * 2f);
                peg.anchoredPosition = new Vector2(0f, 0f);
                Image pegImage = peg.GetComponent<Image>();
                pegImage.sprite = clothespinArt;
                pegImage.preserveAspect = false;
                pegImage.raycastTarget = false;
            }
            card.gameObject.AddComponent<TimelineCardHover>()
                .Setup(angle, cardHoverScale, cardY,
                    source => InspectCard(source, data.Name, data.Description, true));
            if (animate)
                card.DOAnchorPosY(cardY, slideDuration).SetDelay(i * waveDelay)
                    .SetEase(Ease.OutBack);
        }
    }

    public void InspectHandCard(ActivityCardDrag card)
    {
        if (card != null)
            InspectCard((RectTransform)card.transform, card.DisplayName,
                card.Description, false);
    }

    private void InspectCard(RectTransform source, string cardName,
        string description, bool fromTimeline)
    {
        if ((fromTimeline && !open) || source == null || inspectionCard != null) return;
        if (hand == null) hand = FindFirstObjectByType<ActivityCardAvailability>();
        Canvas canvas = GetComponent<Canvas>().rootCanvas;
        RectTransform root = (RectTransform)canvas.transform;
        Camera camera = canvas.renderMode == RenderMode.ScreenSpaceOverlay ?
            null : canvas.worldCamera;
        Vector2 screen = RectTransformUtility.WorldToScreenPoint(camera,
            source.TransformPoint(source.rect.center));
        RectTransformUtility.ScreenPointToLocalPointInRectangle(root,
            screen, camera, out Vector2 start);
        inspectionFromTimeline = fromTimeline;

        inspectionShade = Box("Fundo da inspeção", root, Color.clear, true);
        Fill(inspectionShade, 0f, 0f);
        Button backdrop = inspectionShade.GetComponent<Button>();
        backdrop.transition = Selectable.Transition.None;
        backdrop.onClick.AddListener(() => CloseInspection(false));
        inspectionCard = Box("Carta em inspeção", root, Color.white, false);
        inspectionCard.anchorMin = inspectionCard.anchorMax = new Vector2(0.5f, 0.5f);
        inspectionCard.pivot = new Vector2(0.5f, 0.5f);
        inspectionCard.sizeDelta = source.rect.size;
        inspectionCard.anchoredPosition = start;
        inspectionCard.localScale = source.localScale;
        Image original = source.GetComponent<Image>();
        Image image = inspectionCard.GetComponent<Image>();
        image.sprite = original.sprite;
        image.color = original.color;
        image.preserveAspect = true;
        if (image.sprite == null || image.sprite.name.Contains("9-SlicedBox"))
            Label(cardName, inspectionCard, 16, new Color(0.55f, 0.1f, 0.1f));
        float gap = Mathf.Max(32f,
            hand != null ? hand.InspectionDescriptionGap : 18f);
        float panelWidth = Mathf.Clamp(root.rect.width * 0.24f, 240f, 390f);
        float panelHeight = Mathf.Clamp(root.rect.height * 0.27f, 140f, 260f);
        float scale = Mathf.Min(root.rect.width * 0.38f / source.rect.width,
            root.rect.height * 0.68f / source.rect.height);
        float rightRoom = root.rect.width * 0.5f - panelWidth - gap - 16f;
        scale = Mathf.Min(scale, Mathf.Max(1f, rightRoom * 2f /
            source.rect.width));
        scale = Mathf.Max(1f, scale);
        RectTransform template = hand != null ? hand.InspectionDescriptionTemplate : null;
        if (template != null)
        {
            inspectionDescription = Instantiate(template, root, false);
            inspectionDescription.name = "Descrição da inspeção";
            inspectionDescription.gameObject.SetActive(true);
            inspectionDescription.anchorMin = inspectionDescription.anchorMax =
                new Vector2(0.5f, 0.5f);
            inspectionDescription.pivot = new Vector2(0f, 0.5f);
            inspectionDescription.sizeDelta = new Vector2(panelWidth, panelHeight);
            float panelX = source.rect.width * scale * 0.5f + gap;
            inspectionDescription.anchoredPosition = new Vector2(panelX + 16f, 0f);
            Image descriptionBackground = inspectionDescription.GetComponent<Image>();
            if (descriptionBackground != null)
            {
                // Same dark background used by CardRewardChoice tooltips.
                descriptionBackground.sprite = null;
                descriptionBackground.type = Image.Type.Simple;
                descriptionBackground.color = new Color(0.1f, 0.09f, 0.07f, 0.92f);
                descriptionBackground.raycastTarget = false;
            }
            CanvasGroup panelGroup = inspectionDescription.GetComponent<CanvasGroup>();
            if (panelGroup == null)
                panelGroup = inspectionDescription.gameObject.AddComponent<CanvasGroup>();
            panelGroup.alpha = 0f;
            panelGroup.interactable = panelGroup.blocksRaycasts = false;
            Text text = inspectionDescription.GetComponentInChildren<Text>(true);
            if (text != null)
            {
                text.text = string.IsNullOrWhiteSpace(description) ?
                    "Sem descrição desta carta." : description;
                text.fontSize = 14;
                text.color = Color.white;
                text.resizeTextForBestFit = true;
                text.resizeTextMinSize = 11;
                text.resizeTextMaxSize = 14;
                text.alignment = TextAnchor.MiddleLeft;
                RectTransform textRect = text.rectTransform;
                textRect.anchorMin = Vector2.zero;
                textRect.anchorMax = Vector2.one;
                textRect.offsetMin = new Vector2(16f, 14f);
                textRect.offsetMax = new Vector2(-16f, -14f);
            }
        }
        inspectionSource = source.GetComponent<CanvasGroup>();
        if (inspectionSource == null)
            inspectionSource = source.gameObject.AddComponent<CanvasGroup>();
        inspectionSource.alpha = 0f;
        if (!fromTimeline)
        {
            source.GetComponent<ActivityCardDrag>()?.EndHoverForInspection();
            hand?.SuspendHoverForInspection();
        }
        if (fromTimeline) scroll.enabled = false;
        inspectionTween = DOTween.Sequence()
            .Join(inspectionShade.GetComponent<Image>().DOFade(0.52f, 0.38f))
            .Join(inspectionCard.DOAnchorPos(Vector2.zero, 0.45f)
                .SetEase(Ease.OutCubic))
            .Join(inspectionCard.DOScale(scale, 0.45f)
                .SetEase(Ease.OutBack))
            .Join(inspectionCard.DOLocalRotate(Vector3.zero, 0.45f))
            .OnComplete(() =>
            {
                TimelineCardInspection inspection =
                    inspectionCard.gameObject.AddComponent<TimelineCardInspection>();
                inspection.Configure(inspectionTilt, inspectionShift,
                    inspectionFollowSpeed);
                inspection.Begin(canvas);
            });
        if (inspectionDescription != null)
        {
            float panelX = inspectionDescription.anchoredPosition.x - 16f;
            inspectionTween.Join(inspectionDescription.DOAnchorPosX(panelX, 0.38f)
                .SetEase(Ease.OutCubic));
            inspectionTween.Join(inspectionDescription.GetComponent<CanvasGroup>()
                .DOFade(1f, 0.3f));
        }
    }

    private void CloseInspection(bool immediate)
    {
        if (inspectionCard == null) return;
        inspectionTween?.Kill();
        inspectionCard.DOKill();
        inspectionShade.GetComponent<Image>().DOKill();
        TimelineCardInspection tilt = inspectionCard.GetComponent<TimelineCardInspection>();
        if (tilt != null) tilt.Stop();
        RectTransform card = inspectionCard;
        RectTransform shade = inspectionShade;
        RectTransform descriptionPanel = inspectionDescription;
        CanvasGroup source = inspectionSource;
        inspectionCard = inspectionShade = null;
        inspectionDescription = null;
        inspectionSource = null;
        bool fromTimeline = inspectionFromTimeline;
        inspectionFromTimeline = false;
        if (fromTimeline) scroll.enabled = true;
        void Finish()
        {
            if (source != null) source.alpha = 1f;
            if (card != null) Destroy(card.gameObject);
            if (shade != null) Destroy(shade.gameObject);
            if (descriptionPanel != null) Destroy(descriptionPanel.gameObject);
        }
        if (immediate || source == null || !source.gameObject.activeInHierarchy ||
            (fromTimeline && !open))
        {
            Finish();
            return;
        }
        Canvas canvas = GetComponent<Canvas>().rootCanvas;
        RectTransform root = (RectTransform)canvas.transform;
        Camera camera = canvas.renderMode == RenderMode.ScreenSpaceOverlay ?
            null : canvas.worldCamera;
        RectTransform target = (RectTransform)source.transform;
        Vector2 screen = RectTransformUtility.WorldToScreenPoint(camera,
            target.TransformPoint(target.rect.center));
        RectTransformUtility.ScreenPointToLocalPointInRectangle(root,
            screen, camera, out Vector2 destination);
        inspectionTween = DOTween.Sequence()
            .Join(card.DOAnchorPos(destination, 0.32f).SetEase(Ease.InOutCubic))
            .Join(card.DOScale(1f, 0.32f).SetEase(Ease.InCubic))
            .Join(card.DOLocalRotate(Vector3.zero, 0.25f))
            .Join(shade.GetComponent<Image>().DOFade(0f, 0.32f))
            .OnComplete(Finish);
        if (descriptionPanel != null)
            inspectionTween.Join(descriptionPanel.GetComponent<CanvasGroup>()
                .DOFade(0f, 0.2f));
    }

    private static RectTransform Empty(string name, Transform parent)
    {
        var node = new GameObject(name, typeof(RectTransform));
        node.layer = 5;
        RectTransform rect = (RectTransform)node.transform;
        rect.SetParent(parent, false);
        return rect;
    }

    private static RectTransform Box(string name, Transform parent, Color color, bool button)
    {
        RectTransform rect = Empty(name, parent);
        Image image = rect.gameObject.AddComponent<Image>();
        image.color = color;
        if (button) rect.gameObject.AddComponent<Button>().targetGraphic = image;
        return rect;
    }

    private RectTransform Label(string value, Transform parent, int size, Color color)
    {
        RectTransform rect = Empty(value, parent);
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = rect.offsetMax = Vector2.zero;
        Text label = rect.gameObject.AddComponent<Text>();
        label.font = font;
        label.fontSize = size;
        label.text = value;
        label.color = color;
        label.alignment = TextAnchor.MiddleCenter;
        label.raycastTarget = false;
        return rect;
    }

    private static void Fill(RectTransform rect, float x, float y)
    {
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = new Vector2(x, y);
        rect.offsetMax = new Vector2(-x, -y);
    }

    private static void Clear(Transform parent)
    {
        for (int i = parent.childCount - 1; i >= 0; i--)
        {
            GameObject child = parent.GetChild(i).gameObject;
            child.transform.DOKill();
            child.SetActive(false);
            child.transform.SetParent(null, false);
            if (Application.isPlaying) Destroy(child);
            else DestroyImmediate(child);
        }
    }
}
